#ifndef PLATE_C
#define PLATE_C
#include "TED.hpp"

class plate{
private:
    
    
public:
    Vector2 pos;
    Image localMap;
    Color color;

    plate(Vector2 pos, Image localMap);
    ~plate();
    void render();
};

// initialises the plate
plate::plate(Vector2 pos, Image localMap){
    this->pos = pos;
    this->localMap = localMap;
    this->color = (Color){
        rand()%256,
        rand()%256,
        rand()%256,
        255
    };
}

plate::~plate(){
    UnloadImage(this->localMap);
}

// renders the plate
void plate::render(){
    Texture2D temp = LoadTextureFromImage(this->localMap);

    
    DrawTexture(temp,0,0, WHITE);
    


}
#endif