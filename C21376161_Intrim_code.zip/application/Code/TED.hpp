#ifndef TED_H
#define TED_H

#include <iostream>
#include <raylib.h>
#include <rlgl.h>
#include <math.h>
#include <list>

#include "world.cpp"
#include "plate.cpp"
#include "gridCell.cpp"


#endif