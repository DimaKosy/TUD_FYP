/*
C21376161
These are a mess and where only used for quick testing
*/

#include "TED_TEST.hpp"

int main(int argc, char ** arg){
    getLineEquation_test();

    getLineIntersection_test();

    

    return 0;
}