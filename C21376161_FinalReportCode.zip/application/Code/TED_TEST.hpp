/*
C21376161
These are a mess and where only used for quick testing
*/

#ifndef TED_TEST_H
#define TED_TEST_H

#include "TED.hpp"
#include "test_functions.cpp"


#endif